import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const STAGES = [
  { key: 'import', label: 'Импорт', description: 'Получение выгрузок из маркетплейса, платежного шлюза и банка' },
  { key: 'normalize', label: 'Нормализация', description: 'Единые даты, суммы, идентификаторы и статусы' },
  { key: 'match', label: 'Сопоставление', description: 'Связь заказа, оплаты, комиссии, возврата и выплаты' },
  { key: 'classify', label: 'Классификация', description: 'Выручка, комиссия, возврат, спорная операция' },
  { key: 'exceptions', label: 'Исключения', description: 'Выявление расхождений и неполных цепочек' },
  { key: 'export', label: 'Реестр', description: 'Подготовка данных для учетной системы' },
];

const SOURCES = ['Marketplace', 'Payment Gateway', 'Bank', 'Logistics', 'Internal OMS'];
const CHANNELS = ['Ozon', 'Wildberries', 'Собственный сайт'];
const EVENT_TYPES = {
  ORDER: 'Заказ',
  PAYMENT: 'Оплата',
  COMMISSION: 'Комиссия',
  LOGISTICS: 'Логистика',
  RETURN: 'Возврат',
  PAYOUT: 'Выплата',
};

function seededRandom(seed) {
  let value = seed % 2147483647;
  if (value <= 0) value += 2147483646;
  return () => {
    value = (value * 16807) % 2147483647;
    return (value - 1) / 2147483646;
  };
}

function formatRub(value) {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0,
  }).format(value || 0);
}

function formatDate(date) {
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(date));
}

function addDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result.toISOString().slice(0, 10);
}

function createEvent({ source, eventType, orderId, channel, amount, date, status = 'ok', externalId, note }) {
  return {
    id: `${source.slice(0, 3).toUpperCase()}-${eventType}-${orderId}-${Math.random().toString(36).slice(2, 7)}`,
    source,
    eventType,
    orderId,
    channel,
    amount: Math.round(amount),
    date,
    status,
    externalId: externalId || `${orderId}-${eventType}`,
    note: note || '',
  };
}

function generateDemoEvents(mode = 'balanced') {
  const seedMap = { balanced: 7341, returns: 1903, peak: 5521 };
  const rand = seededRandom(seedMap[mode] || 7341);
  const baseDate = '2026-04-01';
  const events = [];
  const orderCount = mode === 'peak' ? 42 : 36;

  for (let i = 1; i <= orderCount; i += 1) {
    const orderId = `ORD-${String(1000 + i).padStart(4, '0')}`;
    const channel = CHANNELS[Math.floor(rand() * CHANNELS.length)];
    const gross = 2200 + Math.floor(rand() * 18500);
    const feeRate = channel === 'Собственный сайт' ? 0.028 : 0.105 + rand() * 0.055;
    const logistics = channel === 'Собственный сайт' ? 180 + rand() * 260 : 220 + rand() * 520;
    const commission = gross * feeRate;
    const orderDate = addDays(baseDate, Math.floor(rand() * 25));
    const paymentDate = addDays(orderDate, rand() > 0.15 ? 0 : 1);
    const payoutDate = addDays(orderDate, 3 + Math.floor(rand() * 8));

    const isReturn = mode === 'returns' ? rand() < 0.32 : rand() < 0.18;
    const missingPayout = rand() < 0.08;
    const mismatch = rand() < 0.12;
    const missingPayment = rand() < 0.05;
    const delayed = rand() < 0.12;

    events.push(createEvent({
      source: 'Internal OMS',
      eventType: 'ORDER',
      orderId,
      channel,
      amount: gross,
      date: orderDate,
      externalId: `${orderId}-OMS`,
      note: 'Заказ создан в операционной системе',
    }));

    if (!missingPayment) {
      events.push(createEvent({
        source: 'Payment Gateway',
        eventType: 'PAYMENT',
        orderId,
        channel,
        amount: gross,
        date: paymentDate,
        externalId: `PAY-${orderId}`,
        note: 'Подтверждена оплата покупателем',
      }));
    }

    events.push(createEvent({
      source: 'Marketplace',
      eventType: 'COMMISSION',
      orderId,
      channel,
      amount: -commission,
      date: addDays(orderDate, 1),
      externalId: `FEE-${orderId}`,
      note: 'Удержание комиссии посредника',
    }));

    events.push(createEvent({
      source: 'Logistics',
      eventType: 'LOGISTICS',
      orderId,
      channel,
      amount: -logistics,
      date: addDays(orderDate, 1 + Math.floor(rand() * 4)),
      externalId: `LOG-${orderId}`,
      note: 'Логистическое удержание',
    }));

    let returnAmount = 0;
    if (isReturn) {
      returnAmount = gross * (rand() > 0.35 ? 1 : 0.45 + rand() * 0.35);
      events.push(createEvent({
        source: 'Marketplace',
        eventType: 'RETURN',
        orderId,
        channel,
        amount: -returnAmount,
        date: addDays(orderDate, 5 + Math.floor(rand() * 12)),
        status: 'review',
        externalId: `RET-${orderId}`,
        note: returnAmount >= gross * 0.95 ? 'Полный возврат' : 'Частичный возврат',
      }));
    }

    if (!missingPayout) {
      const expectedPayout = gross - commission - logistics - returnAmount;
      const payoutShift = mismatch ? (rand() > 0.5 ? 1 : -1) * (250 + Math.floor(rand() * 2100)) : 0;
      events.push(createEvent({
        source: 'Bank',
        eventType: 'PAYOUT',
        orderId,
        channel,
        amount: expectedPayout + payoutShift,
        date: addDays(payoutDate, delayed ? 7 : 0),
        status: mismatch || delayed ? 'review' : 'ok',
        externalId: `BNK-${orderId}`,
        note: delayed ? 'Выплата поступила позже ожидаемого срока' : 'Фактическое поступление на расчетный счет',
      }));
    }
  }

  return events
    .map((event, index) => ({ ...event, sequence: index + 1 }))
    .sort((a, b) => new Date(a.date) - new Date(b.date) || a.sequence - b.sequence);
}

function normalizeEvent(event) {
  const amount = Number(String(event.amount).replace(',', '.')) || 0;
  return {
    ...event,
    normalizedAmount: Math.round(amount),
    normalizedDate: new Date(event.date).toISOString().slice(0, 10),
    normalizedKey: `${event.orderId}`.trim().toUpperCase(),
    accountingSign: amount >= 0 ? 'debit' : 'credit',
  };
}

function reconcileEvents(rawEvents) {
  const normalized = rawEvents.map(normalizeEvent);
  const groups = normalized.reduce((acc, event) => {
    const key = event.normalizedKey;
    if (!acc[key]) acc[key] = [];
    acc[key].push(event);
    return acc;
  }, {});

  const records = Object.entries(groups).map(([orderId, items]) => {
    const sum = (type) => items.filter((item) => item.eventType === type).reduce((total, item) => total + item.normalizedAmount, 0);
    const order = sum('ORDER');
    const payment = sum('PAYMENT');
    const commission = sum('COMMISSION');
    const logistics = sum('LOGISTICS');
    const returns = sum('RETURN');
    const payout = sum('PAYOUT');
    const expectedPayout = order + commission + logistics + returns;
    const diff = payout - expectedPayout;
    const dates = items.map((item) => new Date(item.normalizedDate).getTime());
    const minDate = Math.min(...dates);
    const maxDate = Math.max(...dates);
    const daysInCycle = Math.round((maxDate - minDate) / (1000 * 60 * 60 * 24));
    const hasPayment = items.some((item) => item.eventType === 'PAYMENT');
    const hasPayout = items.some((item) => item.eventType === 'PAYOUT');
    const hasReturn = items.some((item) => item.eventType === 'RETURN');
    const channel = items[0]?.channel || 'Не определен';

    const issues = [];
    if (!hasPayment) issues.push('нет события оплаты');
    if (!hasPayout) issues.push('нет банковской выплаты');
    if (Math.abs(diff) > 50 && hasPayout) issues.push(`расхождение ${formatRub(diff)}`);
    if (daysInCycle > 10) issues.push('длинный цикл расчета');
    if (hasReturn) issues.push('требуется проверка возврата');

    let status = 'matched';
    if (issues.length > 0) status = 'warning';
    if (!hasPayment || !hasPayout || Math.abs(diff) > 1000) status = 'exception';

    return {
      orderId,
      channel,
      events: items.sort((a, b) => new Date(a.normalizedDate) - new Date(b.normalizedDate)),
      order,
      payment,
      commission,
      logistics,
      returns,
      payout,
      expectedPayout,
      diff,
      daysInCycle,
      issues,
      status,
      revenueForAccounting: hasReturn ? order + returns : order,
      controlComment: issues.length ? issues.join('; ') : 'цепочка расчетов согласована',
    };
  });

  return records.sort((a, b) => {
    const severity = { exception: 0, warning: 1, matched: 2 };
    return severity[a.status] - severity[b.status] || a.orderId.localeCompare(b.orderId);
  });
}

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const headers = lines.shift().split(',').map((header) => header.trim());
  return lines.map((line, index) => {
    const values = line.split(',').map((value) => value.trim());
    const obj = Object.fromEntries(headers.map((header, i) => [header, values[i] ?? '']));
    return {
      id: obj.id || `CSV-${index + 1}`,
      sequence: index + 1,
      source: obj.source || 'CSV',
      eventType: obj.eventType || obj.type || 'ORDER',
      orderId: obj.orderId || obj.order || `CSV-${index + 1}`,
      channel: obj.channel || 'Импорт CSV',
      amount: Number(obj.amount || 0),
      date: obj.date || new Date().toISOString().slice(0, 10),
      status: obj.status || 'ok',
      externalId: obj.externalId || obj.id || `CSV-${index + 1}`,
      note: obj.note || 'Загружено из CSV',
    };
  });
}

function downloadFile(filename, content, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function statusLabel(status) {
  return {
    matched: 'Согласовано',
    warning: 'На проверку',
    exception: 'Исключение',
  }[status] || status;
}

function StagePipeline({ activeStageIndex, progress }) {
  return (
    <section className="pipeline-card">
      <div className="section-heading">
        <span>Жизненный цикл обработки</span>
        <strong>{Math.min(100, Math.round(progress))}%</strong>
      </div>
      <div className="progress-track" aria-label="Прогресс обработки">
        <span style={{ width: `${Math.min(100, progress)}%` }} />
      </div>
      <div className="pipeline-grid">
        {STAGES.map((stage, index) => (
          <div
            key={stage.key}
            className={`stage ${index < activeStageIndex ? 'done' : ''} ${index === activeStageIndex ? 'active' : ''}`}
          >
            <div className="stage-dot">{index + 1}</div>
            <div>
              <h3>{stage.label}</h3>
              <p>{stage.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function MetricCard({ label, value, hint }) {
  return (
    <div className="metric-card">
      <p>{label}</p>
      <strong>{value}</strong>
      <span>{hint}</span>
    </div>
  );
}

function StatusChart({ records }) {
  const counts = useMemo(() => {
    const initial = { matched: 0, warning: 0, exception: 0 };
    records.forEach((record) => { initial[record.status] += 1; });
    return initial;
  }, [records]);
  const max = Math.max(1, ...Object.values(counts));
  return (
    <div className="chart-card">
      <div className="section-heading"><span>Результат сверки</span><small>по заказам</small></div>
      {Object.entries(counts).map(([status, value]) => (
        <div className="bar-row" key={status}>
          <span>{statusLabel(status)}</span>
          <div className="bar-track"><i className={status} style={{ width: `${(value / max) * 100}%` }} /></div>
          <strong>{value}</strong>
        </div>
      ))}
    </div>
  );
}

function ChannelChart({ records }) {
  const rows = useMemo(() => {
    const map = new Map();
    records.forEach((record) => {
      if (!map.has(record.channel)) map.set(record.channel, { channel: record.channel, orders: 0, net: 0, issues: 0 });
      const row = map.get(record.channel);
      row.orders += 1;
      row.net += record.expectedPayout;
      if (record.status !== 'matched') row.issues += 1;
    });
    return [...map.values()].sort((a, b) => b.orders - a.orders);
  }, [records]);
  const max = Math.max(1, ...rows.map((row) => row.orders));
  return (
    <div className="chart-card">
      <div className="section-heading"><span>Каналы продаж</span><small>объем и риски</small></div>
      {rows.map((row) => (
        <div className="channel-row" key={row.channel}>
          <div>
            <strong>{row.channel}</strong>
            <span>{row.orders} заказов · {row.issues} на проверку</span>
          </div>
          <div className="bar-track"><i style={{ width: `${(row.orders / max) * 100}%` }} /></div>
          <b>{formatRub(row.net)}</b>
        </div>
      ))}
    </div>
  );
}

function EventTable({ records, selectedId, setSelectedId }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Заказ</th>
            <th>Канал</th>
            <th>Выручка</th>
            <th>Удержания</th>
            <th>Выплата</th>
            <th>Отклонение</th>
            <th>Статус</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record) => (
            <tr key={record.orderId} className={selectedId === record.orderId ? 'selected' : ''} onClick={() => setSelectedId(record.orderId)}>
              <td><button className="link-button">{record.orderId}</button></td>
              <td>{record.channel}</td>
              <td>{formatRub(record.order)}</td>
              <td>{formatRub(record.commission + record.logistics + record.returns)}</td>
              <td>{formatRub(record.payout)}</td>
              <td className={Math.abs(record.diff) > 50 ? 'negative' : 'positive'}>{formatRub(record.diff)}</td>
              <td><span className={`badge ${record.status}`}>{statusLabel(record.status)}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function LifecyclePanel({ record }) {
  if (!record) {
    return (
      <div className="empty-state">
        <strong>Выберите заказ из реестра</strong>
        <p>Здесь комиссия увидит восстановленную цепочку событий: заказ, оплату, комиссию, возврат и банковскую выплату.</p>
      </div>
    );
  }

  return (
    <div className="lifecycle-card">
      <div className="section-heading">
        <span>Жизненный цикл {record.orderId}</span>
        <span className={`badge ${record.status}`}>{statusLabel(record.status)}</span>
      </div>
      <div className="summary-grid mini">
        <MetricCard label="Ожидаемая выплата" value={formatRub(record.expectedPayout)} hint="заказ − комиссии − возвраты" />
        <MetricCard label="Факт банка" value={formatRub(record.payout)} hint="по выписке" />
        <MetricCard label="Отклонение" value={formatRub(record.diff)} hint={record.controlComment} />
      </div>
      <div className="timeline">
        {record.events.map((event, index) => (
          <div className="timeline-item" key={event.id}>
            <div className="timeline-index">{index + 1}</div>
            <div>
              <strong>{EVENT_TYPES[event.eventType] || event.eventType}</strong>
              <p>{event.source} · {formatDate(event.normalizedDate)} · {formatRub(event.normalizedAmount)}</p>
              <span>{event.note}</span>
            </div>
          </div>
        ))}
      </div>
      {record.issues.length > 0 && (
        <div className="issues-box">
          <strong>Контрольные замечания</strong>
          <ul>
            {record.issues.map((issue) => <li key={issue}>{issue}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}

function ProcessingLog({ rawEvents, processedCount }) {
  const lastEvents = rawEvents.slice(Math.max(0, processedCount - 7), processedCount).reverse();
  return (
    <div className="log-card">
      <div className="section-heading"><span>Поток событий</span><small>{processedCount} обработано</small></div>
      <div className="log-list">
        {lastEvents.length === 0 && <p className="muted">Запустите обработку, чтобы увидеть поток событий.</p>}
        {lastEvents.map((event) => (
          <div className="log-line" key={`${event.id}-${event.sequence}`}>
            <i />
            <span>{event.sequence}</span>
            <strong>{EVENT_TYPES[event.eventType] || event.eventType}</strong>
            <b>{event.orderId}</b>
            <em>{formatRub(event.amount)}</em>
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [mode, setMode] = useState('balanced');
  const [rawEvents, setRawEvents] = useState(() => generateDemoEvents('balanced'));
  const [processedCount, setProcessedCount] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedId, setSelectedId] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [speed, setSpeed] = useState(18);
  const timerRef = useRef(null);

  const progress = rawEvents.length ? (processedCount / rawEvents.length) * 100 : 0;
  const activeStageIndex = Math.min(STAGES.length - 1, Math.floor((progress / 100) * STAGES.length));
  const processedEvents = rawEvents.slice(0, processedCount);
  const records = useMemo(() => reconcileEvents(processedEvents), [processedEvents]);
  const finalRecords = useMemo(() => reconcileEvents(rawEvents), [rawEvents]);
  const recordsForDisplay = processedCount === rawEvents.length ? records : reconcileEvents(processedEvents);

  const filteredRecords = useMemo(() => {
    return recordsForDisplay.filter((record) => {
      const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
      const matchesQuery = !query || record.orderId.toLowerCase().includes(query.toLowerCase()) || record.channel.toLowerCase().includes(query.toLowerCase());
      return matchesStatus && matchesQuery;
    });
  }, [recordsForDisplay, query, statusFilter]);

  const selectedRecord = recordsForDisplay.find((record) => record.orderId === selectedId) || recordsForDisplay[0];

  const metrics = useMemo(() => {
    const exceptions = finalRecords.filter((record) => record.status === 'exception').length;
    const warnings = finalRecords.filter((record) => record.status === 'warning').length;
    const matched = finalRecords.filter((record) => record.status === 'matched').length;
    const gross = finalRecords.reduce((sum, record) => sum + record.order, 0);
    const manualHoursBefore = Math.round(rawEvents.length * 2.2 / 60);
    const manualHoursAfter = Math.round((exceptions + warnings) * 4 / 60);
    return { exceptions, warnings, matched, gross, manualHoursBefore, manualHoursAfter };
  }, [finalRecords, rawEvents.length]);

  useEffect(() => {
    if (!isRunning) return undefined;
    timerRef.current = window.setInterval(() => {
      setProcessedCount((count) => {
        if (count >= rawEvents.length) {
          setIsRunning(false);
          window.clearInterval(timerRef.current);
          return count;
        }
        const next = Math.min(rawEvents.length, count + 1);
        return next;
      });
    }, speed);
    return () => window.clearInterval(timerRef.current);
  }, [isRunning, rawEvents.length, speed]);

  function resetDataset(nextMode = mode) {
    window.clearInterval(timerRef.current);
    setMode(nextMode);
    setRawEvents(generateDemoEvents(nextMode));
    setProcessedCount(0);
    setIsRunning(false);
    setSelectedId('');
    setActiveTab('overview');
  }

  function startProcessing() {
    if (processedCount >= rawEvents.length) setProcessedCount(0);
    setIsRunning(true);
  }

  function pauseProcessing() {
    setIsRunning(false);
  }

  function finishProcessing() {
    setProcessedCount(rawEvents.length);
    setIsRunning(false);
  }

  function exportCsv() {
    const header = ['orderId', 'channel', 'order', 'commission', 'logistics', 'returns', 'expectedPayout', 'bankPayout', 'difference', 'status', 'comment'];
    const rows = finalRecords.map((record) => [
      record.orderId,
      record.channel,
      record.order,
      record.commission,
      record.logistics,
      record.returns,
      record.expectedPayout,
      record.payout,
      record.diff,
      statusLabel(record.status),
      `"${record.controlComment}"`,
    ].join(','));
    downloadFile('reconciliation-register.csv', [header.join(','), ...rows].join('\n'), 'text/csv;charset=utf-8');
  }

  function exportJson() {
    downloadFile('reconciliation-register.json', JSON.stringify(finalRecords, null, 2), 'application/json');
  }

  function handleUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseCsv(String(reader.result));
        if (parsed.length) {
          window.clearInterval(timerRef.current);
          setRawEvents(parsed);
          setProcessedCount(0);
          setIsRunning(false);
          setSelectedId('');
          setMode('csv');
        }
      } catch (error) {
        alert('Не удалось прочитать CSV. Проверьте заголовки: source,eventType,orderId,channel,amount,date,status,externalId,note');
      }
    };
    reader.readAsText(file);
  }

  return (
    <main className="app-shell">
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">MVP для защиты ВКР · e-commerce reconciliation</div>
          <h1>Платформа автоматизированного учета и контроля расчетных операций</h1>
          <p>
            Демонстрационный продукт обрабатывает более 100 цифровых событий, связывает заказ, оплату,
            комиссию, возврат и банковскую выплату, а затем формирует контрольный реестр для бухгалтерского контура.
          </p>
          <div className="hero-actions">
            {!isRunning ? <button className="primary" onClick={startProcessing}>Запустить обработку</button> : <button className="primary" onClick={pauseProcessing}>Пауза</button>}
            <button onClick={finishProcessing}>Показать итог</button>
            <button onClick={() => resetDataset(mode)}>Сбросить</button>
          </div>
        </div>
        <div className="hero-panel">
          <span>Обрабатывается событий</span>
          <strong>{rawEvents.length}</strong>
          <p>минимальное требование: 100+</p>
          <div className="pulse-orbit"><i /><i /><i /></div>
        </div>
      </section>

      <section className="controls-card">
        <div>
          <label>Сценарий данных</label>
          <select value={mode} onChange={(event) => resetDataset(event.target.value)}>
            <option value="balanced">Сбалансированный месяц</option>
            <option value="returns">Период с повышенными возвратами</option>
            <option value="peak">Пиковые продажи</option>
            {mode === 'csv' && <option value="csv">CSV-импорт</option>}
          </select>
        </div>
        <div>
          <label>Скорость анимации</label>
          <input type="range" min="5" max="80" value={speed} onChange={(event) => setSpeed(Number(event.target.value))} />
        </div>
        <div>
          <label>Загрузка CSV</label>
          <input type="file" accept=".csv,text/csv" onChange={handleUpload} />
        </div>
        <div className="export-actions">
          <button onClick={exportCsv}>Экспорт CSV</button>
          <button onClick={exportJson}>Экспорт JSON</button>
        </div>
      </section>

      <StagePipeline activeStageIndex={activeStageIndex} progress={progress} />

      <section className="summary-grid">
        <MetricCard label="Цифровых событий" value={`${processedCount}/${rawEvents.length}`} hint="заказ, оплата, комиссии, возвраты, выплаты" />
        <MetricCard label="Согласовано" value={metrics.matched} hint="цепочки без существенных отклонений" />
        <MetricCard label="На контроль" value={metrics.warnings + metrics.exceptions} hint="исключения и операции на проверку" />
        <MetricCard label="Потенциал экономии" value={`${Math.max(0, metrics.manualHoursBefore - metrics.manualHoursAfter)} ч`} hint="оценка снижения ручной сверки за месяц" />
      </section>

      <section className="workspace">
        <aside>
          <ProcessingLog rawEvents={rawEvents} processedCount={processedCount} />
          <StatusChart records={recordsForDisplay} />
          <ChannelChart records={recordsForDisplay} />
        </aside>
        <section className="main-panel">
          <div className="tabs">
            {[
              ['overview', 'Обзор'],
              ['exceptions', 'Исключения'],
              ['register', 'Реестр'],
              ['lifecycle', 'Жизненный цикл'],
            ].map(([key, label]) => (
              <button key={key} className={activeTab === key ? 'active' : ''} onClick={() => setActiveTab(key)}>{label}</button>
            ))}
          </div>

          {activeTab === 'overview' && (
            <div className="overview-grid">
              <div className="insight-card large">
                <h2>Что показывает MVP</h2>
                <p>
                  Продукт демонстрирует центральную гипотезу ВКР: расчетная операция в электронной коммерции — это
                  не одиночное поступление денег, а жизненный цикл цифровых событий, которые требуют нормализации,
                  сопоставления и контрольной интерпретации перед отражением в учете.
                </p>
                <div className="logic-grid">
                  <span>Входные данные</span><b>маркетплейс · платежный шлюз · банк · логистика · OMS</b>
                  <span>Алгоритм</span><b>нормализация → матчинг → классификация → исключения</b>
                  <span>Выход</span><b>контрольный реестр, расхождения, экспорт для учетной системы</b>
                </div>
              </div>
              <div className="insight-card">
                <h3>Финансовый контур</h3>
                <strong>{formatRub(metrics.gross)}</strong>
                <p>валовый объем заказов в демонстрационном массиве</p>
              </div>
              <div className="insight-card">
                <h3>Контрольный фокус</h3>
                <strong>{metrics.exceptions}</strong>
                <p>операций с существенным риском искажения расчетных данных</p>
              </div>
            </div>
          )}

          {activeTab === 'exceptions' && (
            <>
              <div className="panel-toolbar">
                <input placeholder="Поиск по заказу или каналу" value={query} onChange={(event) => setQuery(event.target.value)} />
                <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                  <option value="all">Все статусы</option>
                  <option value="exception">Исключения</option>
                  <option value="warning">На проверку</option>
                  <option value="matched">Согласовано</option>
                </select>
              </div>
              <EventTable records={filteredRecords.filter((record) => record.status !== 'matched')} selectedId={selectedId} setSelectedId={setSelectedId} />
            </>
          )}

          {activeTab === 'register' && (
            <>
              <div className="panel-toolbar">
                <input placeholder="Поиск по заказу или каналу" value={query} onChange={(event) => setQuery(event.target.value)} />
                <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                  <option value="all">Все статусы</option>
                  <option value="exception">Исключения</option>
                  <option value="warning">На проверку</option>
                  <option value="matched">Согласовано</option>
                </select>
              </div>
              <EventTable records={filteredRecords} selectedId={selectedId} setSelectedId={setSelectedId} />
            </>
          )}

          {activeTab === 'lifecycle' && <LifecyclePanel record={selectedRecord} />}
        </section>
      </section>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
